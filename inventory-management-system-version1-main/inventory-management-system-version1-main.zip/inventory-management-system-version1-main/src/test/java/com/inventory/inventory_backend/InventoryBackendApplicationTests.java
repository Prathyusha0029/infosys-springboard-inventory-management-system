// package com.inventory.inventory_backend;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
// class InventoryBackendApplicationTests {

// 	@Test
// 	void contextLoads() {
// 	}

// }
